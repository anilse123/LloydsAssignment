package assignment2API;

import java.util.List;
import java.util.ArrayList;
import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class testcase2 {
    @Test
    public void getcall_TC01_PeopleCall3() {

        // Set the base URI
        RestAssured.baseURI = "https://swapi.dev/api/people/3/";

        // Send GET request to fetch the person details
        Response response = RestAssured.get();

        // Validate and print the status code
        int statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode, 200, "Status code is not as expected");

        // Validate and print the content type
  //      String contentType = response.getContentType();
  //      Assert.assertTrue(contentType.contains("application/json"), "Content type is not as expected");

        // Parse the JSON response
        JsonPath jsonPath = response.jsonPath(); //This is an important line to convert everyting to JSON format, so that the requirements could be verified easily
        
        // Validate the 'name'
        String actualName = jsonPath.getString("name");
        String expectedName = "R2-D2";
        Assert.assertEquals(actualName, expectedName, "Name is not as expected");
        //Assert is the TESTNG 

        // Validate the 'skin_color'
        String actualSkinColor = jsonPath.getString("skin_color");
        String expectedSkinColor = "white, blue";
        Assert.assertEquals(actualSkinColor, expectedSkinColor, "Skin color is not as expected");

        // Fetch the list of film URLs
        List<String> filmUrls = jsonPath.getList("films");

        // Expected film titles
        List<String> expectedFilmTitles = new ArrayList<>();
        expectedFilmTitles.add("A New Hope");
        expectedFilmTitles.add("The Empire Strikes Back");
        expectedFilmTitles.add("Return of the Jedi");
        expectedFilmTitles.add("The Phantom Menace");
        expectedFilmTitles.add("Attack of the Clones");
        expectedFilmTitles.add("Revenge of the Sith");

        // List to hold actual film titles
        List<String> actualFilmTitles = new ArrayList<>();

        // Iterate over the film URLs and fetch the title for each
        for (String filmUrl : filmUrls) {
            // Send GET request for each film URL
            Response filmResponse = RestAssured.get(filmUrl);

            // Parse the film response to get the title
            String title = filmResponse.jsonPath().getString("title");

            // Add the title to the actualFilmTitles list
            actualFilmTitles.add(title);
        }

        // Validate the film titles
        Assert.assertEquals(actualFilmTitles, expectedFilmTitles, "Film titles are not as expected");
    }

}
