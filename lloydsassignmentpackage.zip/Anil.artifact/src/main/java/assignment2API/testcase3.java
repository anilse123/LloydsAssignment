package assignment2API;

import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class testcase3 {

    @Test
    public void getcall_TC02_StarShips9() {

        // Set the base URI for the starship details
        RestAssured.baseURI = "https://swapi.dev/api/starships/9/";

        // Send GET request to fetch the starship details
        Response response = RestAssured.get();

        // Validate and print the status code
        int statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode, 200, "Status code is not as expected");

        // Validate and print the content type
        String contentType = response.getContentType();
        Assert.assertTrue(contentType.contains("application/json"), "Content type is not as expected");

        // Parse the JSON response
        JsonPath jsonPath = response.jsonPath();

        // Validate the 'name'
        String actualName = jsonPath.getString("name");
        String expectedName = "Death Star";
        Assert.assertEquals(actualName, expectedName, "Name is not as expected");

        // Validate the 'crew'
        String actualCrew = jsonPath.getString("crew");
        String expectedCrew = "342,953";
        Assert.assertEquals(actualCrew, expectedCrew, "Crew count is not as expected");
    }

}
