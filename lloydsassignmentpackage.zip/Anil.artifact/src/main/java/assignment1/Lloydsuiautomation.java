package assignment1;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class Lloydsuiautomation {

	// Initialize the logger
    private static final Logger logger = LoggerFactory.getLogger(Lloydsuiautomation.class);

    // Method to read postcodes from an Excel file
    public List<String> readPostcodesFromExcel(String filePath) {
        List<String> postcodes = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> iterator = sheet.iterator();

            while (iterator.hasNext()) {
                Row row = iterator.next();
                Cell cell = row.getCell(0);
                postcodes.add(cell.getStringCellValue());
            }

        } catch (IOException e) {
            logger.error("Error reading Excel file", e);
        }
        return postcodes;
    }

    @Test
    public void browser_actions() {
        // Path to the Excel file
        String excelFilePath = "./TestData/UIPostcode.xlsx";

        // Read postcodes from Excel
        List<String> postcodes = readPostcodesFromExcel(excelFilePath);

        // Initialize Playwright
        Playwright pw = Playwright.create();
        Browser browser = pw.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(false));
        Page page = browser.newPage();
        page.navigate("https://www.lloydsbank.com/");
        
        // Click on 'Find a branch' link text
        page.locator("text=Find a branch").click();
      //  page.locator("#accept").click();  // Accept cookies
        Locator locate = page.locator("#accept");
        if (locate.isVisible())
        {
        	locate.locator("#accept");
        	System.out.println("cookies accepted");
        }
        else
        {
        	System.out.println("cookies not displayed");
        }
        

        // Iterate over each postcode
        for (String postcode : postcodes) {
            // Input postcode in the text field
            page.locator("#q").fill(postcode);
            page.locator("#q").press("ArrowDown");
            page.locator("#q").press("Enter");
            
            page.waitForTimeout(3000);  // Waits for 3 seconds
            //this is not dynamic wait , this is explicit wait

            // Get the branch name and address
            String branchName = page.locator("(//a[@class='Teaser-titleLink'])[1]").textContent();
            String branchAddress = page.locator("(//span[@class='c-address-street-1'])[1]").textContent();

            // Log the branch details
            logger.info("Postcode: {}", postcode);
            logger.info("Branch Name: {}", branchName);
            logger.info("Branch Address: {}", branchAddress);
            
            System.out.println("Postcode using system.out: " + postcode);
        }

        // Close the browser
        browser.close();
    }
}
